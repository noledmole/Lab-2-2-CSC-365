INSERT INTO COUNTRIES (CountryId,CountryName,Continent)
VALUES
(1, 'usa', 1),
(2, 'germany', 2),
(3, 'france', 2),
(4, 'japan', 3),
(5, 'italy', 2),
(6, 'sweden', 2),
(7, 'uk', 2),
(8, 'korea', 3),
(9, 'russia', 2),
(10, 'nigeria', 4),
(11, 'australia', 5),
(12, 'new zealand', 5),
(13, 'egypt', 4),
(14, 'mexico', 1),
(15, 'brazil', 1);