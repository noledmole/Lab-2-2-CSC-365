--Dylan Watanabe, Bowden Widmann, Amanda Diaz, Noel Murti

DROP TABLE IF EXISTS MARATHON;

CREATE TABLE MARATHON (
    Place INT,
    Time VARCHAR(255),
    Pace VARCHAR(255),
    GroupPlace INT,
    `Group` VARCHAR(255),
    Age INT,
    Sex VARCHAR(255),
    BIBNumber INT NOT NULL,
    FirstName VARCHAR(255),
    LastName VARCHAR(255),
    Town VARCHAR(255),
    State VARCHAR(255),
    PRIMARY KEY (BIBNumber,FirstName,LastName)
);