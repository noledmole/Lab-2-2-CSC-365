DROP TABLE IF EXISTS ROOMS, RESERVATIONS;

CREATE TABLE ROOMS (
    RoomId VARCHAR(255) UNIQUE NOT NULL,
    roomName VARCHAR(255),
    beds INT,
    bedType VARCHAR(255),
    maxOccupancy INT,
    basePrice DECIMAL(10,2),
    decor VARCHAR(255),
    PRIMARY KEY (RoomId)
);

CREATE TABLE RESERVATIONS (
    Code INT NOT NULL,
    Room VARCHAR(255),
    CheckIn DATE NOT NULL,
    CheckOut DATE,
    Rate DECIMAL(10,2),
    LastName VARCHAR(255),
    FirstName VARCHAR(255),
    Adults INT,
    Kids INT,
    PRIMARY KEY (Room, CheckIn),
    FOREIGN KEY (Room) REFERENCES ROOMS(RoomId)
);