--Dylan Watanabe, Bowden Widmann, Amanda Diaz, Noel Murti

INSERT INTO GRAPES(ID, Grape, Color) VALUES(1, 'Barbera', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(2, 'Cabernet Franc', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(3, 'Cabernet Sauvingnon', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(4, 'Chardonnay', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(5, 'Grenache', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(6, 'Malbec', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(7, 'Marsanne', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(8, 'Merlot', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(9, 'Mourvedre', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(10, 'Muscat', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(11, 'Petite Sirah', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(12, 'Pinot Noir', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(13, 'Riesling', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(14, 'Roussanne', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(15, 'Sangiovese', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(16, 'Sauvignon Blanc', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(17, 'Syrah', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(18, 'Tempranillo', 'Red');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(19, 'Viognier', 'White');
INSERT INTO GRAPES(ID, Grape, Color) VALUES(20, 'Zinfandel', 'Red');