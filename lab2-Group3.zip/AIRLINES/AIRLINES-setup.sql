DROP TABLE IF EXISTS AIRLINES, AIRPORT, FLIGHTS;

CREATE TABLE AIRLINES (
    Id INT UNIQUE NOT NULL,
    Airline  VARCHAR(255),
    Abbreviation VARCHAR(255),
    Country VARCHAR(255),
    PRIMARY KEY(Id)
);

CREATE TABLE AIRPORT (
    City VARCHAR(255),
    AirportCode VARCHAR(3) UNIQUE NOT NULL,
    AirportName VARCHAR(255),
    Country VARCHAR(255),
    CountryAbbrev VARCHAR(255),
    PRIMARY KEY(AirportCode)
);

CREATE TABLE FLIGHTS(
    Airline INT,
    FlightNo INT NOT NULL,
    SourceAirport VARCHAR(3),
    DestAirport VARCHAR(3),
    PRIMARY KEY (Airline,FlightNo),
    FOREIGN KEY (Airline) REFERENCES AIRLINES(Id),
    FOREIGN KEY (SourceAirport) REFERENCES AIRPORT(AirportCode),
    FOREIGN KEY (DestAirport) REFERENCES AIRPORT(AirportCode)
);