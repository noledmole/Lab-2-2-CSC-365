--Dylan Watanabe, Bowden Widmann, Amanda Diaz, Noel Murti

DROP TABLE IF EXISTS APPELLATION, GRAPES, WINE;

CREATE TABLE APPELLATION (
    No INT UNIQUE NOT NULL,
    Appellation VARCHAR(255) UNIQUE,
    County VARCHAR(255),
    State VARCHAR(255),
    Area VARCHAR(255),
    isAVA VARCHAR(255),
    PRIMARY KEY (No)
);

CREATE TABLE GRAPES (
    ID INT UNIQUE NOT NULL,
    Grape VARCHAR(255) UNIQUE,
    Color VARCHAR(255),
    PRIMARY KEY (ID)
);

CREATE TABLE WINE (
    No INT UNIQUE NOT NULL,
    Grape VARCHAR(255),
    Winery VARCHAR(255),
    Appellation VARCHAR(255),
    Name VARCHAR(255),
    Year INT,
    Price INT,
    Score INT,
    Cases FLOAT(23,4),
    PRIMARY KEY (No),
    FOREIGN KEY (Grape) REFERENCES GRAPES(Grape),
    FOREIGN KEY (Appellation) REFERENCES APPELLATION(Appellation)
);