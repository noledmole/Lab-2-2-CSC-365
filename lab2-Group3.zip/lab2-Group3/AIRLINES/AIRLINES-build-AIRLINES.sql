--Dylan Watanabe, Bowden Widmann, Amanda Diaz, Noel Murti


INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(1, 'United Airlines', 'UAL', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(2, 'US Airways', 'USAir', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(3, 'Delta Airlines', 'Delta', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(4, 'Southwest Airlines', 'Southwest', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(5, 'American Airlines', 'American', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(6, 'Northwest Airlines', 'Northwest', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(7, 'Continental Airlines', 'Continental', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(8, 'JetBlue Airways', 'JetBlue', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(9, 'Frontier Airlines', 'Frontier', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(10, 'AirTran Airways', 'AirTran', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(11, 'Allegiant Air', 'Allegiant', 'USA');
INSERT INTO AIRLINES(Id, Airline, Abbreviation, Country) VALUES(12, 'Virgin America', 'Virgin', 'USA');
