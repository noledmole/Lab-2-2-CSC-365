INSERT INTO BAND (Id,Firstname,Lastname)
VALUES
(1, 'Solveig', 'Heilo'),
(2, 'Marianne', 'Sveen'),
(3, 'Anne-Marit', 'Bergheim'),
(4, 'Turid', 'Jorgensen');
