DROP TABLE IF EXISTS TEACHERS, LIST;

CREATE TABLE TEACHERS (
    LastName VARCHAR(255) NOT NULL,
    FirstName VARCHAR(255) NOT NULL,
    Classroom INT NOT NULL,
    PRIMARY KEY (Classroom)
);

CREATE TABLE LIST (
    LastName VARCHAR(255) NOT NULL,
    FirstName VARCHAR(255) NOT NULL,
    Grade INT NOT NULL,
    Classroom INT NOT NULL,
    PRIMARY KEY (LastName, FirstName, Grade, Classroom),
    CHECK(Classroom >= 100),
    CHECK(Classroom <= 112)
);